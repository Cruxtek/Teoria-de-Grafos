# Definimos la cola priorizada
class ColaPriorizada:
  # Initialize the list
  def __init__(self):
    self.items = []
  # Check if the queue is empty
  def is_empty(self):
    return len(self.items) == 0
  # Insert an element with a given priority
  def insert(self, item, priority):
    self.items.append((priority, item))
  # Remove and return the element with the highest priority
  def remove(self):
    # Sort the list by priority in descending order
    self.items.sort(reverse=True)
    # Pop and return the first element of the list
    return self.items.pop()[1]
# Create an instance of the priority queue
pq = PriorityQueue()
# Insert some elements with different priorities
pq.insert("A", 3)
pq.insert("B", 1)
pq.insert("C", 2)
# Remove and print the elements in order of priority
while not pq.is_empty():
  print(pq.remove())        
