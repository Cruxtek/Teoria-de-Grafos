import matplotlib.pyplot as plt
import networkx as nx
import itertools
from matplotlib.lines import Line2D
from networkx.algorithms import bipartite
import math

import math
#ingresa los datos n=nodos y m=aristas
n = int(input('ingese el numero de nodos:\n')) # nodes
m = int(input('ingrese el numero de aristas:\n')) # edges
#G = nx.complete_graph(n,m)
G = nx.gnm_random_graph(n, m)
     

# make a test graph
#n = 6# nodes
#m = 12 # edges
#G = nx.complete_graph(n,m)
#G = nx.gnm_random_graph(n, m)
#G = nx.random_regular_graph(n,m)
#G = nx.Graph([(0, 1), (0, 2), (0, 3), (1, 2), (1, 3)])
# and define some color strings (you'll get this array from the dataframe)
#h4 = nx.draw_networkx_edges(G, pos=pos, width=6, edge_color='black')
print('cubierto de aristas minimo')
print(sorted(nx.min_edge_cover(G)))
# Function that calculates Edge Cover 
def edgeCover(m):
     
    result = 0
     
    result = math.ceil(m/ 2.0)
     
    return result


#toma la arista
arista = edgeCover(m)
print('cubierta de aristas maximo')
print (int(arista))
_c = 'rgb'*arista # way too many colors, trim after

clrs = [c for c in _c[:arista]]

plt.ion()

plt.figure(figsize = (9, 7), num=1); plt.clf()
# draw the graph in several steps
pos = nx.spring_layout(G)
h4 = nx.draw_networkx_edges(G, pos=pos, width=6, edge_color='black')
#pos = nx.min_edge_cover(G)
h1 = nx.draw_networkx_nodes(G, pos=pos, node_color = 'black',
                            alpha = 0.9, node_size = 300, linewidths=6)
# we need the LineCollection of the edges to produce the legend (h2)
h2 = nx.draw_networkx_edges(G, pos=pos, width=6, edge_color=clrs)

# and just show the node labels to check the labels are right!
h3 = nx.draw_networkx_labels(G, pos=pos, font_size=20, font_color='c')


#https://stackoverflow.com/questions/19877666/add-legends-to-linecollection-plot - uses plotted data to define the color but here we already have colors defined, so just need a Line2D object.
def make_proxy(clr, mappable, **kwargs):
    return Line2D([0, 1], [0, 1], color=clr, **kwargs)

# generate proxies with the above function
proxies = [make_proxy(clr, h2, lw=5) for clr in clrs]
# and some text for the legend -- you should use something from df.
#labels = ["{}->{}".format(fr, to) for (fr, to) in G.edges()]

plt.legend(proxies, labels)
#label2 = "el color negro quiere decir que no pinta"
plt.show()


     

