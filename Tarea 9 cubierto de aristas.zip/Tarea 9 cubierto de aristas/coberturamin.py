import matplotlib.pyplot as plt
import networkx as nx
import itertools
from matplotlib.lines import Line2D
from networkx.algorithms import bipartite
import math
#ingresa los datos n=nodos y m=aristas
n = int(input('ingese el numero de nodos:\n')) # nodes
m = int(input('ingrese el numero de aristas:\n')) # edges
#G = nx.complete_graph(n,m)
G = nx.gnm_random_graph(n, m)
#imprime la cobertura minima de un grafo
print(sorted(nx.min_edge_cover(G)))
#dibuja el grafo real
pos = nx.spring_layout(G)
#grafo minimo
G1 = nx.Graph()
G1.add_edges_from(sorted(nx.min_edge_cover(G)))
#pinta los nodos de un color y los colorea
h1 = nx.draw_networkx_nodes(G1, pos=pos, node_color = 'black',
                            alpha = 0.9, node_size = 300, linewidths=6)
# pinta el grafo original (h2)
h2 = nx.draw_networkx_edges(G, pos=pos, width=6, edge_color='black')
#pinta el grafo de cobertura minima llamando G1 y en color rojo
h3 = nx.draw_networkx_edges(G1, pos=pos, width=6, edge_color='Red')
# pinta los nomnbres del grafo es decir sus numeros
h4 = nx.draw_networkx_labels(G1, pos=pos, font_size=20, font_color='c')
#guardamos la imagen por si las moscas
plt.savefig('grafocobertura.jpg')
plt.show()


     

