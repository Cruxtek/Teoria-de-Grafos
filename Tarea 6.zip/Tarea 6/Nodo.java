public class Nodo{
	int info;
	Nodo liga;

	public Nodo(int dato) {
		info=dato;
		liga=null;
	}	
	
}