import java.util.Scanner;
public class Principal {

	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		Nodo hojas[]=new Nodo[100];
		Lista2 buscar[]=new Lista2[100];
		@SuppressWarnings("resource")
		Scanner in=new Scanner(System.in);
		grafos G=new grafos();
        int  nodoP;
        G.LeeGrafo("grafo0.txt");
	   G.escribematriz();    
	    
	    System.out.println();
	   
	    //Recorrido a lo Profundo 
	    System.out.println("Del 1 al "+G.getNN() +" con cual Nodo desea empezar");
	    nodoP=in.nextInt();
	    System.out.println("\nRecorrido a lo profundo de un grafo");
	    int [] recorrido=new int[G.getNN()+1];
	    recorrido=G.recorridoProfundo(nodoP);
	    for(int i=0;i<recorrido.length;i++){
	        System.out.print(recorrido[i]+" ");
	    }
	    
	    System.out.println();
	    
	    System.out.println("Hojas del arbol");
	    for(int i=0;i<recorrido.length;i++){
		 	hojas = G.convArbol(recorrido[i]);
	    }
	
	    for(int i=0;i<G.getCon();i++){
	    	System.out.print(hojas[i].info+" ");
	    }
	    
	    System.out.println();
	    System.out.println("Recorrido de hojas");
	    int i=0;
	    for(int j=0;j<G.getCon();j++){
	    buscar[j]=new Lista2();
	    }
	    
	    for(int j=0;j<G.getCon();j++){  
	    Nodo aux2=hojas[j];
	    while(aux2!=null){
		   System.out.print(aux2.info+" ");
		   buscar[i].inserta(aux2.info);
		   aux2=aux2.liga;
	 	   }
	    i++;
	    System.out.println(" ");
	    }
	  
	    //G.escribematriz();
	    System.out.println(" ");
	    System.out.println("Determinar si es Bipartito o no :");
	    G.ciclosFun(recorrido,buscar);
	    //G.escribematriz();
	    }
	}