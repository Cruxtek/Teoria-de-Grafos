import java.io.*;
import java.util.StringTokenizer;

class grafos{
 int NN;
 int conta=0;
 int M[][] = new int[20][20];
 Nodo hoj[]=new Nodo[100];
 Cola c=new Cola(100);

 Nodo raiz1=null;
 static int con;
 
 int[] visitados=new int[50];
 int[] visitados2=new int[50];

 //escribe matriz
 public void escribematriz(){
 	int i,j;
 	System.out.println(" NODOS = "+NN);
 	System.out.println(" Matriz de Adyacencias");
 	System.out.print(" ");
 	for(i=1;i<=NN;i++)System.out.print("  "+i);	
 	System.out.println();
 	
 	for(i=1;i<=NN; i++){
 		System.out.print(i+"  ");
 		for (j=1;j<=NN;j++)
 		System.out.print(M[i][j]+"  ");	
 		System.out.println();
 	}
 }

 //Lee archivo con los datos del grafo
 @SuppressWarnings("deprecation")
public void LeeGrafo(String arch) {
  		FileInputStream fp;
		DataInputStream f;
		String linea = null;
		int token1,token2,i,j;
 try{
		fp = new FileInputStream(arch);
		f = new DataInputStream(fp);
		linea=f.readLine();
		
		NN=Integer.parseInt(linea); 
		System.out.println(" Numero de Nodos: "+NN);
		// Inicializamos la matriz con ceros
  		for (i=1;i<=NN;i++)
  		     for(j=1;j<=NN; j++)
  		        M[i][j]=0;        
  		// Leemos el archivo linea por linea
		do{
			linea = f.readLine();
			if (linea!=null){
				StringTokenizer tokens=new StringTokenizer(linea); 
				token1 = Integer.parseInt(tokens.nextToken());
				token2 = Integer.parseInt(tokens.nextToken());
				// escribimos en pantalla los datos leidos transformados en numeros
				System.out.println(token1+" "+token2);
				// almacenamos en la matriz
				M[token1][token2]=1;
				M[token2][token1]=1;
				}  
			}while(linea != null);
		fp.close();	
	}
         catch (FileNotFoundException exc){
             System.out.println ("El archivo " + arch + " no fue encontrado ");
         }
         catch (IOException exc){
             System.out.println (exc);
         }
  }
 
//recorrido a lo profundo
 public int[] recorridoProfundo(int Nodo){
	 for(int i=0;i<=NN;i++) //marcamos nodos como no visitados
		 visitados2[i]=0;
	 Pila entrada=new Pila(100);
	 int []recProfundo=new int[NN];
	 entrada.push(Nodo);
	 int cont=0;
	 while(entrada.vacia()!=1){	
		 int k=entrada.pop();
		 if(visitados2[k]==0){
			 recProfundo[cont]=k;
			 visitados2[k]=1;
			 cont++;
		 }
		 for(int j=NN;j>=1;j--){
			 if((M[k][j]==1)&&(visitados2[j]!=1)){
				 entrada.push(j);				
			 }
		 }
	 }
	 return recProfundo; 
}

//convertir grafo a arbol 
Nodo ant=null;
Nodo hoja=null;
 public Nodo[] convArbol(int valor){
	 Nodo newNodo=new Nodo(valor);
	 conta ++;
	 Nodo actual=newNodo;
	 if(raiz1==null){
		 raiz1=newNodo;
		 ant=actual;
	 }
	 else{
		 if(M[ant.info][valor]==1){
			 newNodo.liga=ant;
			 M[ant.info][valor]=2;
			 M[valor][ant.info]=2;
			 ant=actual;
			}		 
		 else{
			 hoj[con]=ant;
			 con++;
			 while(M[ant.info][valor]!=1){	 
				 ant=ant.liga;
			 }
		if(M[ant.info][valor]==1){
				 M[ant.info][valor]=2;
				 M[valor][ant.info]=2;
			     newNodo.liga=ant;
			     ant=actual;
			 }
	   }	
	 }
	 if(conta==NN){
		 hoj[con]=newNodo;
		 con++;
	 }
	 return hoj;
}

 public Nodo buscar(Lista2 [] lista,int x){	
	 for(int i=0;i<con;i++){
	 Nodo aux=lista[i].raiz;
	 while(aux!=null){
		 if(aux.info==x){
			 return aux;
			 }
		 aux=aux.liga;
		 }
	 }
	 return null;
}
 
//ciclos fundamentales
 public void ciclosFun(int a[],Lista2 [] l){
	 @SuppressWarnings("unused")
	int con=1,j=0,band=0,tam=a.length;
	for(int k=0;k<tam-1;k++){
		int h=a[k];
	        j=k;
		for(int e=1;e<=tam;e++){
			con=1;
		if(M[h][e]==1){
		  Nodo x=buscar(l,e);
		  Nodo y=buscar(l,h);
		  Nodo aux=x;
		  M[h][e]=2;
		  M[e][h]=2;
		   while(aux.info!=y.info){
			   System.out.print(aux.info+" ");
			   aux=aux.liga;
			   con++;
		   }
		   System.out.print(aux.info+" ");
		   System.out.print(x.info+" ");
		   System.out.println();
    		if(con%2!=0)band=1;
			}
		}
}
	if(band==0)System.out.println("\nSi es bipartito");
	else
		System.out.println("\nNo es bipartito");
}
 
  public int getNN() {
	return NN;
  }
  
  public void setNN(int nN) {
	NN = nN;
  }
  
  public static int getCon() {
	return con;
  }

}