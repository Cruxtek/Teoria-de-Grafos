public class Lista1 {
	Nodo raiz;
	public Lista1() {
		raiz=null;
	}
	public void inserta(int x){
		Nodo temp=new Nodo(x);
		if(raiz==null)
			raiz=temp;
		else{
			temp.liga=raiz;
			raiz=temp;
		}	
	}
	public void recorrer(){
		Nodo aux=raiz;
		while(aux!=null){
			System.out.print(aux.info+" ");
			aux=aux.liga;
			
		}
		System.out.println();
	}
	public Nodo buscar(int x){
		Nodo aux=raiz;
		while(aux!=null){
			if(aux.info==x){
				return aux;
			}
			aux=aux.liga;
		}
		return null;
	}
	public int eliminar(){
		Nodo aux=raiz;
		raiz=raiz.liga;
		aux.liga=null;
		return aux.info;
	}

}
