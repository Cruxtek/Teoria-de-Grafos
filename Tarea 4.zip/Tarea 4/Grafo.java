/**
 * @(#)Grafo.java
 *
 *  rescribiendo mario moctezuma mendoza
 * @codigo del doctor pedro bello lopez 
 * @version 1.00 2024/8/22
 *
 */
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.ArrayList;
public class Grafo{
	int MA[][]=new int[50][50];
	int visitados[]=new int[100];
	int NN;
	int aristas;
 	int origen[] = new int[100]; 
 	int destino[] = new int[100];
    public Grafo() 
    {
    	NN=0;
    }
 public void escribematriz()
 {
 	int i,j;
 	System.out.println(" NODOS = "+NN);
 	System.out.println(" Matriz de Adyacencias");
 	System.out.print(" ");
 	for(i=1;i<=NN;i++)System.out.print("  "+i);	
 	System.out.println();
 	
 	for(i=1;i<=NN; i++)
 	{
 		System.out.print(i+"  ");
 		for (j=1;j<=NN;j++)
 		System.out.print(MA[i][j]+"  ");	
 		System.out.println();
 	}
 }
    public void LeeGrafo(String arch) //Lee archivo con los datos del grafo
  {
  		FileInputStream fp;
		DataInputStream f;
		String linea = null;
		int token1,token2,i,j;
	
 try
     {
		fp = new FileInputStream(arch);
		f = new DataInputStream(fp);
		linea=f.readLine();
		
		NN=Integer.parseInt(linea); 
	
		System.out.println(" Numero de Nodos: "+NN);
		// Inicializamos la matriz DE ADYACENCIAS con ceros
  		for (i=1;i<=NN;i++)
  		     for(j=1;j<=NN; j++)
  		        MA[i][j]=0;
  		        
  		// Leemos el archivo linea por linea
		do {
			linea = f.readLine();
			if (linea!=null){
				              StringTokenizer tokens=new StringTokenizer(linea); 
				              token1 = Integer.parseInt(tokens.nextToken());
				              token2 = Integer.parseInt(tokens.nextToken());
				              // escribimos en pantalla los datos leidos transformados en numeros
				                // escribimos en pantalla los datos leidos transformados en numeros
				              //System.out.println(token1+" "+token2);
				              //origen[aristas]=token1;
				              //destino[aristas]=token2; aristas++;
				              // almacenamos en la matriz
				              MA[token1][token2]=1;
				              MA[token2][token1]=1;
				            }  
			}while(linea != null);
		fp.close();	
	}
	
         catch (FileNotFoundException exc)
         {
             System.out.println ("El archivo " + arch + " no fue encontrado ");
         }
         
         catch (IOException exc)
         {
             System.out.println (exc);
         }
  		
  }
   
  public int getNN() {
	return NN;
  }
  /*public void aloprofundo(int inicio) {
    GraphViz gv1 = new GraphViz();
    gv1.addln(gv1.start_graph());

    Pila P = new Pila(50); 
    int[] visitados = new int[NN + 1];
    int n, j;
    String cad;
    for (j = 0; j <= NN; j++) visitados[j] = 0;

    P.push(inicio);
    visitados[inicio] = 1;

    while (P.vacia() == 0) {
        n = P.pop(); 
        	
        System.out.print(n + "->");

        for (j = NN; j >=1; j--) {
            if (MA[n][j] != 0 && visitados[j] == 0) {
                P.push(j); 
                cad = n + "->" + j;
                gv1.addln(cad);
                visitados[n] = 1;
            }
        }
    }
    System.out.println();
    gv1.addln(gv1.end_graph());

    String type = "jpg";
    File out = new File("recorrido Alo Profundo." + type); // Windows
    gv1.writeGraphToFile(gv1.getGraph(gv1.getDotSource(), type), out);
}*/
   public int[] recorridoProfundo(int Nodo){
   
	    int visitados[] = new int[NN + 1];
        int i;

        for (i = 0; i <= NN; i++)
            visitados[i] = 0;

        Pila P = new Pila(NN);
        P.push(Nodo);
        visitados[Nodo] = 1;
        System.out.print(Nodo + " ");

        while (P.vacia() != 1) {
            int nodoActual = P.obtenerUltimo();
            boolean encontrado = false;

            for (i = 1; i <= NN; i++) {
                if (MA[nodoActual][i] == 1 && visitados[i] == 0) {
                    P.push(i);
                    visitados[i] = 1;
                    System.out.print(i + " ");
                    
                    // Guardamos la arista en el recorrido DFS
                    origen[aristas] = nodoActual;
                    destino[aristas] = i;
                    aristas++;
                    
                    encontrado = true;
                    break;
                }
            }

            if (!encontrado) {
                P.pop();
            }
        }
        System.out.println();

       return visitados;
	}
   /*public void dibujarGrafo1(String nombre)
   {
      GraphViz gv = new GraphViz();
      String cad;
      gv.addln(gv.start_NOgraph());
      
         
       for (int i=0;i<aristas;i++)
       {
       	cad=this.origen[i]+"--"+destino[i];
       	System.out.println(cad+" ");
       	gv.addln(cad);
       } 
      
               
      gv.addln(gv.end_graph());
      System.out.println(gv.getDotSource());
      
      String type = "jpg";
      File out = new File(nombre+"." + type);    // Windows
      gv.writeGraphToFile( gv.getGraph( gv.getDotSource(), type ), out );
   }*/
	
public void dibujarGrafo2(String nombre)
   {
     GraphViz gv1 = new GraphViz();
    //gv1.addln(gv1.start_graph());
     String cad;
     gv1.addln(gv1.start_NOgraph());
      
         
       for (int i=0;i<aristas;i++)
       {
       	cad=this.origen[i]+"--"+destino[i];
       	System.out.println(cad+" ");
       	gv1.addln(cad);	
       } 
      
     gv1.addln(gv1.end_graph());
    //System.out.println(gv1.getDotSource());
    String type = "jpg";
    File out = new File(nombre+"."+ type);    // Windows
    gv1.writeGraphToFile( gv1.getGraph( gv1.getDotSource(), type ), out );	
 
   }
	@SuppressWarnings("static-access")
    public static void main(String a[])
    {
    	@SuppressWarnings("resource")
     
      
		Scanner in=new Scanner(System.in);
    	Grafo G=new Grafo();
    	int  nodoP;
    	G.LeeGrafo("grafo1.txt");
    	  System.out.println();
	     G.escribematriz();
	    //Recorrido a lo Profundo 
	    System.out.println("Del 1 al "+G.getNN()+" con cual Nodo desea empezar:");
	    nodoP=in.nextInt();
	    System.out.println("\nRecorrido a lo profundo de un grafo");
	    int [] recorrido=G.recorridoProfundo(nodoP);
	    for(int i=0;i<recorrido.length;i++)
	    {
       	    
	    System.out.println ("\n"+recorrido[i]+"");
	   
	    }
	    G.dibujarGrafo2("aloProfundo");
	    System.out.println();
	    }
    	
}
  