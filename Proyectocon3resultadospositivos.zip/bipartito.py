from collections import deque

def es_bipartito(matriz_adyacencia):
    """
    Verifica si un grafo es bipartito usando la matriz de adyacencia.

    Parámetros:
    - matriz_adyacencia: lista de listas que representa la matriz de adyacencia.

    Retorna:
    - True si el grafo es bipartito, False en caso contrario.
    """
    n = len(matriz_adyacencia)  # Número de nodos
    colores = [-1] * n  # -1: no visitado, 0 y 1: colores de los nodos

    # Revisar cada componente conexa del grafo
    for inicio in range(n):
        if colores[inicio] == -1:  # Si el nodo no ha sido visitado
            # Realizar BFS desde este nodo
            cola = deque([inicio])
            colores[inicio] = 0  # Asignar el primer color

            while cola:
                nodo_actual = cola.popleft()

                for vecino in range(n):
                    if matriz_adyacencia[nodo_actual][vecino] == 1:  # Existe una arista
                        if colores[vecino] == -1:  # Si no ha sido coloreado
                            # Colorear al vecino con el color opuesto
                            colores[vecino] = 1 - colores[nodo_actual]
                            cola.append(vecino)
                        elif colores[vecino] == colores[nodo_actual]:  # Conflicto de colores
                            return False

    return True