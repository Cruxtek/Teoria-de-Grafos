import bipartito
import matriz
import cactus
import networkx as nx
import es_arbol
import matplotlib.pyplot as plt

# Número de nodos
num_nodos = 10

# Conexiones (aristas) del grafo
conexiones = [
    (0, 1), (1, 2), (2, 3),(3, 4),(4, 5), (5, 6),(6, 7),(6,8),(7,9)
]

# Generar la matriz de adyacencia
grafo = matriz.generar_matriz_adyacencia(num_nodos, conexiones)

# Imprimir la matriz de adyacencia
# print("Matriz de adyacencia:")
# for fila in grafo:
#     print(fila)

# Verificar si el grafo es bipartito
if bipartito.es_bipartito(grafo):
    print("El grafo es bipartito.")
else:
    print("El grafo NO es bipartito.")

# Convertir la matriz de adyacencia a un objeto de NetworkX
grafo_nx = nx.Graph()
for a, b in conexiones:
    grafo_nx.add_edge(a, b)

# Verificar si el grafo es un árbol
if es_arbol.es_arbol(grafo_nx):
    print("El grafo es un árbol.")
else:
    print("El grafo NO es un árbol.")


#verifica si es Cactus o no
print("Imprime si el grafo es cactus: \n 'true': si es cactus,\n 'False': no es cactus \n la respuesta es:")
print(cactus.es_grafo_cactus(grafo_nx))

import numpy as np
from networkx.algorithms import approximation as approx

I = approx.maximum_independent_set(grafo_nx)
print(f"Maximo Conjunto independiente Grafo: {I}")

pos = nx.spring_layout(grafo_nx, iterations=100, seed=42)
nx.draw(
    grafo_nx,
    pos=pos,
    with_labels=True,
    node_color=["tab:red" if n in I else "tab:blue" for n in grafo_nx],
)
plt.savefig('MIS.jpg')
plt.show()
