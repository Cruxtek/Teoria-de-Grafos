def generar_matriz_adyacencia(nodos, conexiones):
    """
    Genera la matriz de adyacencia para un grafo.

    Parámetros:
    - nodos: Número de nodos en el grafo.
    - conexiones: Lista de tuplas donde cada tupla (a, b) representa una conexión entre los nodos a y b.

    Retorna:
    - Una matriz de adyacencia representando el grafo.
    """
    # Crear una matriz de nxn inicializada en 0
    matriz = [[0 for _ in range(nodos)] for _ in range(nodos)]

    # Agregar las conexiones a la matriz
    for a, b in conexiones:
        matriz[a][b] = 1
        matriz[b][a] = 1  # Porque el grafo es no dirigido

    return matriz