import networkx as nx

def es_arbol(grafo):
    # 1. Verificar si el grafo es conexo
    if not nx.is_connected(grafo):
        return False  # Si no es conexo, no es un árbol

    # 2. Verificar si el grafo tiene ciclos
    try:
        # Usamos cycle_basis para ver si hay ciclos en un grafo no dirigido
        ciclos = list(nx.cycle_basis(grafo))
        if ciclos:
            return False  # Si encontramos ciclos, no es un árbol
    except nx.NetworkXError:
        return False  # Si hay un error al buscar ciclos, no es un árbol

    # Si el grafo es conexo y no tiene ciclos, es un árbol
    return True