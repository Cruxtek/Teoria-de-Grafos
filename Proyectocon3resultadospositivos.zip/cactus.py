import networkx as nx

def es_grafo_cactus(grafo):
    """
    Verifica si un grafo dado es de tipo cactus.
    
    Un grafo es un cactus si todos sus ciclos tienen a lo sumo un vértice en común.
    La función evalúa esta propiedad revisando:
    1. Si el grafo es conexo.
    2. Si cualquier vértice pertenece a lo sumo a un ciclo en su contexto.
    
    Parámetros:
    grafo (networkx.Graph): El grafo a evaluar.
    
    Retorno:
    bool: True si el grafo es un cactus, False en caso contrario.
    """
    # Un grafo no conexo no puede ser un cactus.
    if not nx.is_connected(grafo):
        return False
    
    # Recorremos los ciclos simples para verificar si hay intersecciones no válidas.
    ciclos = list(nx.cycle_basis(grafo))  # Encuentra todos los ciclos elementales.
    for i in range(len(ciclos)):
        for j in range(i + 1, len(ciclos)):
            # Contar los nodos comunes entre ciclos
            interseccion = set(ciclos[i]) & set(ciclos[j])
            if len(interseccion) > 1:
                return False  # Más de un nodo en común entre dos ciclos invalida el cactus.

    return True  # Si no se encuentran conflictos, el grafo es un cactus.


