
import matplotlib.pyplot as plt # for plotting
from matplotlib.patches import ConnectionPatch # for plotting matching result
import networkx as nx # for plotting graphs
import warnings



plt.figure(figsize=(8, 4))

G1 = nx.Graph()
G1.add_edge(1, 2)
G1.add_edge(1, 4)
G1.add_edge(2, 3)
G1.add_edge(3, 6)
G1.add_edge(4, 5)
G1.add_edge(5, 6)
#G2 = nx.Graph()
#G2.add_edge(1, 2)
#G2.add_edge(1, 3)
#G2.add_edge(2, 4)
#G2.add_edge(3, 6)
#G2.add_edge(4, 5)
#G2.add_edge(6, 5)
#no isomorfo
G2 = nx.Graph()
G2.add_edge(1, 3)
G2.add_edge(1, 5)
G2.add_edge(3, 5)
G2.add_edge(2, 5)
G2.add_edge(2, 4)
G2.add_edge(2, 6)
G2.add_edge(6, 4)
pos1 = nx.spring_layout(G1)
pos2 = nx.spring_layout(G2)
plt.subplot(1, 2, 1)
plt.title('Graph 1')
nx.draw_networkx(G1, pos=pos1)
plt.subplot(1, 2, 2)
plt.title('Graph 2')
nx.draw_networkx(G2, pos=pos2)
#print("")
#nx.set_node_attributes(
#    G1, dict(zip(G1, ["blue", "red", "green", "yellow"])), "label"
#)
#print(nx.set_node_attributes(
    #G1, dict(zip(G1, ["blue", "red", "green", "yellow"])), "label"
#))
#print("")
#nx.set_node_attributes(
 #   G2,
  #  dict(zip([mapped[u] for u in G1], ["blue", "red", "green", "yellow"])),
   # "label",
#)
#print(nx.set_node_attributes(
 #   G1, dict(zip(G1, ["blue", "red", "green", "yellow"])), "label"
#))
#print("")
nx.vf2pp_is_isomorphic(G1, G2, node_label="label")
print('imprime "True" si es isomorfo, "false" si no es isomorfo')
print("")
print(nx.vf2pp_is_isomorphic(G1, G2))
print("")
nx.vf2pp_isomorphism(G1, G2)
#{1: 1, 2: 2, 0: 0, 3: 3}
print(nx.vf2pp_isomorphism(G1, G2))

plt.show()
