public class Cola {
	int entrada, salida, tamanio;
	int []datos=new int[100];
	
	public Cola(int t){
		tamanio=t;
		entrada=0;
		salida=0;
	}
	
	public void insertar(int x){
		datos[entrada]=x;
		entrada++;
	}
	
	public int extraer(){
		return datos[salida++];
		
	}
	
	public int vacia(){
		if(entrada==salida)
			return 1;
		else
			return 0;
	}
	
	public int llena(){
		if(entrada==tamanio)
			return 1;
		else 
			return 0;
	}

	public void escribir(){
		for(int i=salida;i<entrada;i++){
			System.out.print(datos[i]+" ");
		}
		System.out.println();
	}

}
