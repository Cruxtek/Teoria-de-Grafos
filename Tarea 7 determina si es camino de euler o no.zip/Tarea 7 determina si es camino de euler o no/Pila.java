//import java.util.Scanner;
public class Pila {
	int tope, tamanio;
	int datos[]=new int[100];

	public Pila(int t) {
		tamanio=t;
		tope=0;
	}
	public void push(int x){
		datos[tope]=x;
		tope++;
	}
	public int pop(){
		tope--;
		return datos[tope];
	}
	public int vacia(){
		if(tope==0)
			return 1;
		else
			return 0;
	}
	public int llena(){
		if(tope==tamanio)
			return 1;
		else
			return 0;
	}
	public void escribir(){
		for(int i=0;i<tope;i++)
			System.out.print(datos[i]+" ");
			
		System.out.println();
	}
	/*public static int menu(){
		@SuppressWarnings("resource")
		Scanner in=new Scanner(System.in);
		System.out.println("1.- Push\n"
				+ "2.- Pop\n"
				+ "3.- Escribir\n"
				+ "4.- Salir\n");
		System.out.println("Elige tu opcion\n");
		int opc=in.nextInt();
		return opc;
	}*/

}

