import java.util.Scanner;
public class Principal {

	@SuppressWarnings("static-access")
/*	public static void main(String[] args) {
		grafos G=new grafos();
		int [] recorrido=new int[G.getNN()+1];
		Nodo hojas[]=new Nodo[100];
		Lista2 buscar[]=new Lista2[100];
		@SuppressWarnings("resource")
		Scanner in=new Scanner(System.in);
        int  nodoP, opc=0;
        String nombre;
        //Menu 
        do{
        	System.out.println("----------------PROYECTO FINAL ESTRUCTURAS DE DATOS----------------\n"
        			+ "1.- Abrir el archivo del grafo\n"
        			+ "2.-Recorrudo a lo profundo\n"
        			+ "3.- Transformar el grafo a un arbol\n"
        			+ "4.- Obtener los ciclos fundamentales y determinar si el grafo es bipartito\n"
        			+ "5.- Mostrar matriz de adyacencias\n"
        			+ "6.-Salir");
        	System.out.println("Elige una opci�n: \n");
        	opc=in.nextInt();
        	switch(opc){
        		case 1:
        			System.out.println("Da el nombre del archivo para abrir: \n");
        			in.nextLine();
        			nombre=in.nextLine();
        			G.LeeGrafo(nombre);
        			G.escribematriz();
        			System.out.println();
        		break;
        		
        		case 2:
        			//Recorrido_a_lo_Profundo 
        		    System.out.println("Del 1 al "+G.getNN() +" �con cual Nodo desea empezar?");
        		    nodoP=in.nextInt();
        		    System.out.println("\nRecorrido a lo profundo de un grafo");
        		   
        		    recorrido=G.recorridoProfundo(nodoP);
        		 
        		   
        		    for(int i=0;i<recorrido.length;i++){
        		        System.out.print(recorrido[i]+" ");
        		    }
        		    System.out.println();
        			break;
        			
        		case 3:
        			 System.out.println("Hojas del arbol");
        			    for(int i=0;i<recorrido.length;i++){
        				 	hojas = G.convArbol(recorrido[i]);
        			    }
        			
        			    for(int i=0;i<G.getCon();i++){
        			    	System.out.print(hojas[i].info+" ");
        			    }
        			    
        			    System.out.println();
        			    System.out.println("Recorrido de hojas");
        			    int i=0;
        			    for(int j=0;j<G.getCon();j++){
        			    buscar[j]=new Lista2();
        			    }
        			    
        			    for(int j=0;j<G.getCon();j++){  
        			    Nodo aux2=hojas[j];
        			    while(aux2!=null){
        				   System.out.print(aux2.info+" ");
        				   buscar[i].inserta(aux2.info);
        				   aux2=aux2.liga;
        			 	   }
        			    i++;
        			    System.out.println(" ");
        			    }
        			break;
        		case 4:
        			System.out.println(" ");
        		    System.out.println("Ciclos fundamentales:");
        		    G.ciclosFun(recorrido,buscar);
        		    System.out.println();
        			break;
        		case 5:
        			G.escribematriz();
        			System.out.println();
        			break;
        			
        		case 6:
        			System.out.println("El programa ha finalizado\n");
        			break;
        			
        		default:
        			System.out.println("Opci�n no v�lida\n");
        	}
        	
        }while(opc!=6);
        
	    }*/
	
	}