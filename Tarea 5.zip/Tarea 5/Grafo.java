/**
 * @(#)Grafo.java
 *
 *  rescribiendo mario moctezuma mendoza
 * @codigo del doctor pedro bello lopez 
 * @version 1.00 2024/8/22
 *
 */
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.ArrayList;
public class Grafo{
	int MA[][]=new int[50][50];
	int visitados[]=new int[100];
	int NN;
	int aristas;
 	int origen[] = new int[100]; 
 	int destino[] = new int[100];
 	int conta=0;
 	 Nodo hoj[]=new Nodo[100];
 	 Nodo raiz1=null;
 	 static int con;
 	 int[] visitados2=new int[50];

    public Grafo() 
    {
    	NN=0;
    }
 public void escribematriz()
 {
 	int i,j;
 	System.out.println(" NODOS = "+NN);
 	System.out.println(" Matriz de Adyacencias");
 	System.out.print(" ");
 	for(i=1;i<=NN;i++)System.out.print("  "+i);	
 	System.out.println();
 	
 	for(i=1;i<=NN; i++)
 	{
 		System.out.print(i+"  ");
 		for (j=1;j<=NN;j++)
 		System.out.print(MA[i][j]+"  ");	
 		System.out.println();
 	}
 }
    public void LeeGrafo(String arch) //Lee archivo con los datos del grafo
  {
  		FileInputStream fp;
		DataInputStream f;
		String linea = null;
		int token1,token2,i,j;
	
 try
     {
		fp = new FileInputStream(arch);
		f = new DataInputStream(fp);
		linea=f.readLine();
		
		NN=Integer.parseInt(linea); 
	
		System.out.println(" Numero de Nodos: "+NN);
		// Inicializamos la matriz DE ADYACENCIAS con ceros
  		for (i=1;i<=NN;i++)
  		     for(j=1;j<=NN; j++)
  		        MA[i][j]=0;
  		        
  		// Leemos el archivo linea por linea
		do {
			linea = f.readLine();
			if (linea!=null){
				              StringTokenizer tokens=new StringTokenizer(linea); 
				              token1 = Integer.parseInt(tokens.nextToken());
				              token2 = Integer.parseInt(tokens.nextToken());
				              // escribimos en pantalla los datos leidos transformados en numeros
				                // escribimos en pantalla los datos leidos transformados en numeros
				              //System.out.println(token1+" "+token2);
				              //origen[aristas]=token1;
				              //destino[aristas]=token2; aristas++;
				              // almacenamos en la matriz
				              MA[token1][token2]=1;
				              MA[token2][token1]=1;
				            }  
			}while(linea != null);
		fp.close();	
	}
	
         catch (FileNotFoundException exc)
         {
             System.out.println ("El archivo " + arch + " no fue encontrado ");
         }
         
         catch (IOException exc)
         {
             System.out.println (exc);
         }
  		
  }
   
  public int getNN() {
	return NN;
  }
//recorrido a lo profundo
 public int[] Profundo(int Nodo){
	 for(int i=0;i<=NN;i++) //marcamos nodos como no visitados
		 visitados2[i]=0;
	 Pila entrada=new Pila(100);
	 int []recProfundo=new int[NN];
	 entrada.push(Nodo);
	 int cont=0;
	 while(entrada.vacia()!=1){	
		 int k=entrada.pop();
		 if(visitados2[k]==0){
			 recProfundo[cont]=k;
			 visitados2[k]=1;
			 cont++;
		 }
		 for(int j=NN;j>=1;j--){
			 if((MA[k][j]==1)&&(visitados2[j]!=1)){
				 entrada.push(j);				
			 }
		 }
	 }
	 return recProfundo; 
}

   public int[] recorridoProfundo(int Nodo){
   
	    int visitados[] = new int[NN + 1];
        int i;

        for (i = 0; i <= NN; i++)
            visitados[i] = 0;

        Pila P = new Pila(NN);
        P.push(Nodo);
        visitados[Nodo] = 1;
        System.out.print(Nodo + " ");

        while (P.vacia() != 1) {
            int nodoActual = P.obtenerUltimo();
            boolean encontrado = false;

            for (i = 1; i <= NN; i++) {
                if (MA[nodoActual][i] == 1 && visitados[i] == 0) {
                    P.push(i);
                    visitados[i] = 1;
                    System.out.print(i + " ");
                    
                    // Guardamos la arista en el recorrido DFS
                    origen[aristas] = nodoActual;
                    destino[aristas] = i;
                    aristas++;
                    
                    encontrado = true;
                    break;
                }
            }

            if (!encontrado) {
                P.pop();
            }
        }
        System.out.println();

       return visitados;
	}

public void dibujarGrafo2(String nombre)
   {
     GraphViz gv1 = new GraphViz();
    //gv1.addln(gv1.start_graph());
     String cad;
     gv1.addln(gv1.start_NOgraph());
      
         
       for (int i=0;i<aristas;i++)
       {
       	cad=this.origen[i]+"--"+destino[i];
       	System.out.println(cad+" ");
       	gv1.addln(cad);	
       } 
      
     gv1.addln(gv1.end_graph());
    //System.out.println(gv1.getDotSource());
    String type = "jpg";
    File out = new File(nombre+"."+ type);    // Windows
    gv1.writeGraphToFile( gv1.getGraph( gv1.getDotSource(), type ), out );	
 
   }
   
   //convertir grafo a arbol 
Nodo ant=null;
Nodo hoja=null;
 public Nodo[] convArbol(int valor){
	 Nodo newNodo=new Nodo(valor);
	 conta ++;
	 Nodo actual=newNodo;
	 if(raiz1==null){
		 raiz1=newNodo;
		 ant=actual;
	 }
	 else{
		 if(MA[ant.info][valor]==1){
			 newNodo.liga=ant;
			 MA[ant.info][valor]=2;
			 MA[valor][ant.info]=2;
			 ant=actual;
			}		 
		 else{
			 hoj[con]=ant;
			 con++;
			 while(MA[ant.info][valor]!=1){	 
				 ant=ant.liga;
			 }
		if(MA[ant.info][valor]==1){
				 MA[ant.info][valor]=2;
				 MA[valor][ant.info]=2;
			     newNodo.liga=ant;
			     ant=actual;
			 }
	   }	
	 }
	 if(conta==NN){
		 hoj[con]=newNodo;
		 con++;
	 }
	 return hoj;
}

 public Nodo buscar(Lista2 [] lista,int x){	
	 for(int i=0;i<con;i++){
	 Nodo aux=lista[i].raiz;
	 while(aux!=null){
		 if(aux.info==x){
			 return aux;
			 }
		 aux=aux.liga;
		 }
	 }
	 return null;
}
  public void setNN(int nN) {
	NN = nN;
  }
  
  public static int getCon() {
	return con;
  }
 
//ciclos fundamentales
 public void ciclosFun(int a[],Lista2 [] l){
	 @SuppressWarnings("unused")
	int con=1,j=0,band=0,tam=a.length;
	for(int k=0;k<tam-1;k++){
		int h=a[k];
	        j=k;
		for(int e=1;e<=tam;e++){
			con=1;
		if(MA[h][e]==1){
		  Nodo x=buscar(l,e);
		  Nodo y=buscar(l,h);
		  Nodo aux=x;
		  MA[h][e]=2;
		  MA[e][h]=2;
		   while(aux.info!=y.info){
			   System.out.print(aux.info+" ");
			   aux=aux.liga;
			   con++;
		   }
		   System.out.print(aux.info+" ");
		   System.out.print(.info+" ");
		   System.out.print(x.info+" ");
		   System.out.println();
    		if(con%2!=0)band=1;
			}
		}
}
	if(band==0)System.out.println("\nSi es bipartito");
	else
		System.out.println("\nNo es bipartito");
}

   
	@SuppressWarnings("static-access")
    public static void main(String a[])
    {
    	@SuppressWarnings("resource")
     	Nodo hojas[]=new Nodo[100];
      	Lista2 buscar[]=new Lista2[100];
		Scanner in=new Scanner(System.in);
    	Grafo G=new Grafo();
    	int  nodoP;
    	G.LeeGrafo("grafo1.txt");
    	  System.out.println();
	     G.escribematriz();
	    //Recorrido a lo Profundo 
	    System.out.println("Del 1 al "+G.getNN()+" con cual Nodo desea empezar:");
	    nodoP=in.nextInt();
	    System.out.println("\nRecorrido a lo profundo de un grafo");
	    int [] recorrido=new int[G.getNN()+1];
	    recorrido=G.Profundo(nodoP);
	    for(int i=0;i<recorrido.length;i++){
	        System.out.print(recorrido[i]+" ");
	    }
	    
	    System.out.println();
	    System.out.println ("probando el recorrido en graphviz");
	    G.recorridoProfundo(nodoP);
	    System.out.println ("\n el grafo graphviz\ng{");
	    G.dibujarGrafo2("aloProfundo");
	    System.out.println("}");
	    System.out.println(" ");
	    System.out.println("Hojas del arbol");
        			    for(int i=0;i<recorrido.length;i++){
        				 	hojas = G.convArbol(recorrido[i]);
        			    }
        			
        			    for(int i=0;i<G.getCon();i++){
        			    	System.out.print(hojas[i].info+" ");
        			    }
        			    
        			    System.out.println();
        			    System.out.println("Recorrido de hojas");
        			    int i=0;
        			    for(int j=0;j<G.getCon();j++){
        			    buscar[j]=new Lista2();
        			    }
        			    
        			    for(int j=0;j<G.getCon();j++){  
        			    Nodo aux2=hojas[j];
        			    while(aux2!=null){
        				   System.out.print(aux2.info+" ");
        				   buscar[i].inserta(aux2.info);
        				   aux2=aux2.liga;
        			 	   }
        			    i++;
        			    System.out.println(" ");
        			    }
	    System.out.println ("");
        System.out.println ("determinar si el grafo es bipartito\nCiclos:");
         G.ciclosFun(recorrido,buscar);
         System.out.println("");
	    }
}
  