public class Lista2 {
	Nodo raiz;
	int con;

	public Lista2(){
		raiz=null;
		con=0;
	}


	public void inserta(int x ){
		Nodo temp=new Nodo(x);
		con ++;
		if(raiz==null){
			raiz=temp;
			}else{
				Nodo aux=raiz;
				while(aux.liga !=null){
					aux=aux.liga;	
				}
			aux.liga=temp;
		}
	}

	public void recorrer(){
		Nodo aux =raiz;
		while(aux != null){
			System.out.print(aux.info+" ");
			aux=aux.liga;	
			}
		System.out.println(" ");
	}

	public int eliminar(){
		Nodo aux=raiz;
		raiz=raiz.liga;
		aux.liga=null;
		return aux.info;
	}

	public void ordenar(){
		int temp;
		Nodo aux1=raiz;
		Nodo aux2=raiz.liga;
		for(int i=0;i<con;i++){
			aux1=raiz;
			aux2=raiz.liga;
			for(int k=0;k<con-1;k++){
				if(aux1.info>aux2.info){
					temp=aux1.info;
					aux1.info=aux2.info;
					aux2.info=temp; 
					}
				aux1=aux1.liga;  
				aux2=aux2.liga;
				}
			}
		}
	}
