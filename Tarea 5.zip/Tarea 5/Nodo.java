public class Nodo {
	int info;
	Nodo liga;
	Nodo liga2;
	public Nodo(int dato) {
		info=dato;
		liga=null;
		liga2=null;
	}
	
}