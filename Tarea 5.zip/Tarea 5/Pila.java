/**
 * @(#)Pila.java
 *
 * @mario moctezuma mendoza rescrito
 * @codigo estilo Dr Pedro Bello Lopez
 * @version 1.00 2024/8/22
 */
import java.util.ArrayList;
public class Pila {
	int tope, tamanio;
	int datos[]=new int[100];

	public Pila(int t) {
		tamanio=t;
		tope=0;
	}

	public void push(int x){
		datos[tope]=x;
		tope++;
	}
	
	public int pop(){
		tope--;
		return datos[tope];
	}
	
	public int vacia(){
		if(tope==0)
			return 1;
		else
			return 0;
	}
	
	public int llena(){
		if(tope==tamanio)
			return 1;
		else
			return 0;
	}
	
	public void escribir(){
		for(int i=0;i<tope;i++)
			System.out.print(datos[i]+" ");
			
		System.out.println();
	}
	 public int obtenerUltimo() {
        if (vacia() == 1) {
            return -1;
        } else {
            return datos[tope - 1];
        }
    }
  /*  public static void main(String a[])
    {
    	int x;
    	Pila pila = new Pila(5);
    	pila.push(5);
    	pila.push(7);
    	x=pila.pop();
    	x=pila.pop();
    	System.out.println("la pila:"+x);
    	x=pila.vacia();
    	System.out.println("la pila da 1 si esta vacia, 0 si esta ocupada:"+x);
    	x=pila.llena();
    	System.out.println("pila llena:"+x);
    }   */
}