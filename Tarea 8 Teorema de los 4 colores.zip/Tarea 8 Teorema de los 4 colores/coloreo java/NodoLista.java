
public class NodoLista {
    int en,sal,prio;
    NodoLista sigNodo;
    public NodoLista(int e,int s,int prio){
        en=e;
        sal=s;
        this.prio=prio;
    }
    
}
