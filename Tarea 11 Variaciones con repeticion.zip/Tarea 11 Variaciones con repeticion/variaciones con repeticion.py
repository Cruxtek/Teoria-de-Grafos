from itertools import combinations_with_replacement
#donde van las variaciones

n = ['A','Z','U','L']

print (n)
print()
print(list(combinations_with_replacement(n,1)))
print()
print(list(combinations_with_replacement(n,2)))
print()
print(list(combinations_with_replacement(n,3)))
print()
print(list(combinations_with_replacement(n,4)))
print()
